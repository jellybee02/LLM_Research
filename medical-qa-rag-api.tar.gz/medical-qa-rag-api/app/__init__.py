"""
Medical QA/RAG API Application
의료 데이터 기반 QA 및 RAG 시스템
"""

__version__ = "1.0.0"
